<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class labour_data extends Model
{
   public $timestamps = false;
    public  $table = "labour_data";
}
