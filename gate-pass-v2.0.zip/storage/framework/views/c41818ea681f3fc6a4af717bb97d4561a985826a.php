<div class="col-md-12">

    <!-- 1 -->
    <?php if($labour_data->process_stage > 0): ?>
    <a type="button" class="btn btn-success" href="<?php echo e(url('labour/data/scan/edit/'.$labour_data->id)); ?>">
        1 Step Form Complete <i class="fa fa-check-circle" aria-hidden="true"></i> </a>
    <?php else: ?>
    <a type="button" class="btn btn-danger text-light" href="#">
        1 Step Form Complete <i class="fa fa-lock" aria-hidden="true"></i> </a>
    <?php endif; ?>

    <!-- 2 -->
    <?php if($labour_data->process_stage > 1): ?>
    <a type="button" class="btn btn-success" href="<?php echo e(url('labour/data/image/upload/'.$labour_data->id)); ?>" style="margin-left: 20px">
        2 Step Upload / Take picture <i class="fa fa-check-circle" aria-hidden="true"></i> </a>
    <?php else: ?>
    <a type="button" class="btn btn-danger text-light" href="#" style="margin-left: 20px" onClick="alert('First complete this form before moving to the next one');" >
        2 Step Upload / Take picture <i class="fa fa-lock" aria-hidden="true"></i> </a>
    <?php endif; ?>

  <!-- 3 -->
    <?php if($labour_data->process_stage > 1): ?>
    <a type="button" class="btn btn-info" href="<?php echo e(url('labour/data/pdf/print/'.$labour_data->id)); ?>" style="margin-left: 20px">
        3 Step Print PDF <i class="fa fa-check-circle" aria-hidden="true"></i> </a>
    <?php else: ?>
    <a type="button" class="btn btn-danger text-light" href="#" style="margin-left: 20px" onClick="alert('First complete this form before moving to the next one');">
        3 Step Print PDF <i class="fa fa-lock" aria-hidden="true"></i> </a>
    <?php endif; ?>

</div><?php /**PATH C:\xampp\htdocs\gate-pass-v2.0\resources\views/precess_stage_labour.blade.php ENDPATH**/ ?>